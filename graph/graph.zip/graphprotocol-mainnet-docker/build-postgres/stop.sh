#!/bin/bash

systemctl stop postgres
