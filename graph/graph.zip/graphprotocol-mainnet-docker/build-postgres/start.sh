#!/bin/bash

systemctl start postgres
